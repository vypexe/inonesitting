//
//  inonesittingApp.swift
//  inonesitting
//
//  Created by Allen Lin on 5/9/23.
//

import SwiftUI

@main
struct inonesittingApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
